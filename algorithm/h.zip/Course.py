# Stores data about course
class Course:
    # Initializes course
    def __init__(self, id, name):
        # Returns course ID
        self.Id = id
        # Returns course name
        self.Name = name
