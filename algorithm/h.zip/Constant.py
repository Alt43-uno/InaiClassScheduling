class Constant:
    DAYS_NUM = 5
    DAY_HOURS = 4
